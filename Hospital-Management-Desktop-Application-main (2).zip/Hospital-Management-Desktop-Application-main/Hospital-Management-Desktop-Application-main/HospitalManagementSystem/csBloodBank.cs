﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagementSystem
{
    class csBloodBank:csRoom
    {
      
        public static List<csBloodPacket> List_OF_Blood_Packets { get; set; }
    }
}
