﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagementSystem
{
    class csBloodPacket
    {
        public String Blood_Group { get; set; }
        public int Quantity { get; set; }

    }
}
