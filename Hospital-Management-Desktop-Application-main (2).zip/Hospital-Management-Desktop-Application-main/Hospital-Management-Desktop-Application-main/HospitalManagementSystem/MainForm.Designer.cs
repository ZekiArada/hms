﻿
namespace HospitalManagementSystem
{
    partial class MainForn
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForn));
            panelMenu = new System.Windows.Forms.Panel();
            panelUnitsSubMenu = new System.Windows.Forms.Panel();
            btnViewUnit = new System.Windows.Forms.Button();
            btnAddUnit = new System.Windows.Forms.Button();
            btnUnits = new System.Windows.Forms.Button();
            panelSideSlecectedShow = new System.Windows.Forms.Panel();
            panelCapitalSubMenu = new System.Windows.Forms.Panel();
            btnCapitalRecord = new System.Windows.Forms.Button();
            btnCapital = new System.Windows.Forms.Button();
            panelLabSubMenu = new System.Windows.Forms.Panel();
            btnTestsHistory = new System.Windows.Forms.Button();
            btnAddTest = new System.Windows.Forms.Button();
            btnLaboratory = new System.Windows.Forms.Button();
            panelPatientsSubMenu = new System.Windows.Forms.Panel();
            btnPatientRecord = new System.Windows.Forms.Button();
            btnAddPatient = new System.Windows.Forms.Button();
            btnPatientQueue = new System.Windows.Forms.Button();
            btnPatients = new System.Windows.Forms.Button();
            panelDoctorsSubMenu = new System.Windows.Forms.Panel();
            btnSurgeon = new System.Windows.Forms.Button();
            btnLaboratoryTechnician = new System.Windows.Forms.Button();
            btnPharmacist = new System.Windows.Forms.Button();
            btnNurse = new System.Windows.Forms.Button();
            btnDoctor = new System.Windows.Forms.Button();
            btnEmployees = new System.Windows.Forms.Button();
            btnHome = new System.Windows.Forms.Button();
            btnExit = new System.Windows.Forms.Button();
            panelMenuLogo = new System.Windows.Forms.Panel();
            panel = new System.Windows.Forms.Panel();
            panelMenu.SuspendLayout();
            panelUnitsSubMenu.SuspendLayout();
            panelCapitalSubMenu.SuspendLayout();
            panelLabSubMenu.SuspendLayout();
            panelPatientsSubMenu.SuspendLayout();
            panelDoctorsSubMenu.SuspendLayout();
            SuspendLayout();
            // 
            // panelMenu
            // 
            panelMenu.AutoScroll = true;
            panelMenu.BackColor = System.Drawing.Color.FromArgb(0, 121, 162);
            panelMenu.Controls.Add(panelUnitsSubMenu);
            panelMenu.Controls.Add(btnUnits);
            panelMenu.Controls.Add(panelSideSlecectedShow);
            panelMenu.Controls.Add(panelCapitalSubMenu);
            panelMenu.Controls.Add(btnCapital);
            panelMenu.Controls.Add(panelLabSubMenu);
            panelMenu.Controls.Add(btnLaboratory);
            panelMenu.Controls.Add(panelPatientsSubMenu);
            panelMenu.Controls.Add(btnPatients);
            panelMenu.Controls.Add(panelDoctorsSubMenu);
            panelMenu.Controls.Add(btnEmployees);
            panelMenu.Controls.Add(btnHome);
            panelMenu.Controls.Add(btnExit);
            panelMenu.Controls.Add(panelMenuLogo);
            panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            panelMenu.Location = new System.Drawing.Point(0, 0);
            panelMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new System.Drawing.Size(286, 812);
            panelMenu.TabIndex = 1;
            // 
            // panelUnitsSubMenu
            // 
            panelUnitsSubMenu.BackColor = System.Drawing.Color.FromArgb(0, 156, 208);
            panelUnitsSubMenu.Controls.Add(btnViewUnit);
            panelUnitsSubMenu.Controls.Add(btnAddUnit);
            panelUnitsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            panelUnitsSubMenu.Location = new System.Drawing.Point(0, 1246);
            panelUnitsSubMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelUnitsSubMenu.Name = "panelUnitsSubMenu";
            panelUnitsSubMenu.Size = new System.Drawing.Size(265, 108);
            panelUnitsSubMenu.TabIndex = 26;
            // 
            // btnViewUnit
            // 
            btnViewUnit.Dock = System.Windows.Forms.DockStyle.Top;
            btnViewUnit.FlatAppearance.BorderSize = 0;
            btnViewUnit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnViewUnit.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnViewUnit.ForeColor = System.Drawing.Color.White;
            btnViewUnit.Location = new System.Drawing.Point(0, 53);
            btnViewUnit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnViewUnit.Name = "btnViewUnit";
            btnViewUnit.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnViewUnit.Size = new System.Drawing.Size(265, 53);
            btnViewUnit.TabIndex = 3;
            btnViewUnit.Text = "View Unit";
            btnViewUnit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnViewUnit.UseVisualStyleBackColor = true;
            btnViewUnit.Click += btnViewUnit_Click;
            // 
            // btnAddUnit
            // 
            btnAddUnit.Dock = System.Windows.Forms.DockStyle.Top;
            btnAddUnit.FlatAppearance.BorderSize = 0;
            btnAddUnit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAddUnit.ForeColor = System.Drawing.Color.White;
            btnAddUnit.Location = new System.Drawing.Point(0, 0);
            btnAddUnit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnAddUnit.Name = "btnAddUnit";
            btnAddUnit.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnAddUnit.Size = new System.Drawing.Size(265, 53);
            btnAddUnit.TabIndex = 2;
            btnAddUnit.Text = "Add Unit";
            btnAddUnit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAddUnit.UseVisualStyleBackColor = true;
            btnAddUnit.Click += btnAddUnit_Click;
            // 
            // btnUnits
            // 
            btnUnits.Dock = System.Windows.Forms.DockStyle.Top;
            btnUnits.FlatAppearance.BorderSize = 0;
            btnUnits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnUnits.Font = new System.Drawing.Font("Segoe UI", 10F);
            btnUnits.ForeColor = System.Drawing.Color.White;
            btnUnits.Image = (System.Drawing.Image)resources.GetObject("btnUnits.Image");
            btnUnits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnUnits.Location = new System.Drawing.Point(0, 1186);
            btnUnits.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnUnits.Name = "btnUnits";
            btnUnits.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnUnits.Size = new System.Drawing.Size(265, 60);
            btnUnits.TabIndex = 25;
            btnUnits.Text = "Units";
            btnUnits.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnUnits.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnUnits.UseVisualStyleBackColor = true;
            btnUnits.Click += btnUnits_Click;
            // 
            // panelSideSlecectedShow
            // 
            panelSideSlecectedShow.BackColor = System.Drawing.Color.White;
            panelSideSlecectedShow.Location = new System.Drawing.Point(0, 176);
            panelSideSlecectedShow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelSideSlecectedShow.Name = "panelSideSlecectedShow";
            panelSideSlecectedShow.Size = new System.Drawing.Size(2, 60);
            panelSideSlecectedShow.TabIndex = 2;
            // 
            // panelCapitalSubMenu
            // 
            panelCapitalSubMenu.BackColor = System.Drawing.Color.FromArgb(0, 156, 208);
            panelCapitalSubMenu.Controls.Add(btnCapitalRecord);
            panelCapitalSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            panelCapitalSubMenu.Location = new System.Drawing.Point(0, 1127);
            panelCapitalSubMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelCapitalSubMenu.Name = "panelCapitalSubMenu";
            panelCapitalSubMenu.Size = new System.Drawing.Size(265, 59);
            panelCapitalSubMenu.TabIndex = 24;
            // 
            // btnCapitalRecord
            // 
            btnCapitalRecord.Dock = System.Windows.Forms.DockStyle.Top;
            btnCapitalRecord.FlatAppearance.BorderSize = 0;
            btnCapitalRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnCapitalRecord.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnCapitalRecord.ForeColor = System.Drawing.Color.White;
            btnCapitalRecord.Location = new System.Drawing.Point(0, 0);
            btnCapitalRecord.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnCapitalRecord.Name = "btnCapitalRecord";
            btnCapitalRecord.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnCapitalRecord.Size = new System.Drawing.Size(265, 53);
            btnCapitalRecord.TabIndex = 2;
            btnCapitalRecord.Text = "Record";
            btnCapitalRecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCapitalRecord.UseVisualStyleBackColor = true;
            btnCapitalRecord.Click += btnCapitalRecord_Click;
            // 
            // btnCapital
            // 
            btnCapital.Dock = System.Windows.Forms.DockStyle.Top;
            btnCapital.FlatAppearance.BorderSize = 0;
            btnCapital.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnCapital.Font = new System.Drawing.Font("Segoe UI", 10F);
            btnCapital.ForeColor = System.Drawing.Color.White;
            btnCapital.Image = (System.Drawing.Image)resources.GetObject("btnCapital.Image");
            btnCapital.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCapital.Location = new System.Drawing.Point(0, 1067);
            btnCapital.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnCapital.Name = "btnCapital";
            btnCapital.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnCapital.Size = new System.Drawing.Size(265, 60);
            btnCapital.TabIndex = 23;
            btnCapital.Text = "Capital";
            btnCapital.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCapital.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnCapital.UseVisualStyleBackColor = true;
            btnCapital.Click += btnCapital_Click;
            // 
            // panelLabSubMenu
            // 
            panelLabSubMenu.BackColor = System.Drawing.Color.FromArgb(0, 156, 208);
            panelLabSubMenu.Controls.Add(btnTestsHistory);
            panelLabSubMenu.Controls.Add(btnAddTest);
            panelLabSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            panelLabSubMenu.Location = new System.Drawing.Point(0, 958);
            panelLabSubMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelLabSubMenu.Name = "panelLabSubMenu";
            panelLabSubMenu.Size = new System.Drawing.Size(265, 109);
            panelLabSubMenu.TabIndex = 20;
            // 
            // btnTestsHistory
            // 
            btnTestsHistory.Dock = System.Windows.Forms.DockStyle.Top;
            btnTestsHistory.FlatAppearance.BorderSize = 0;
            btnTestsHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnTestsHistory.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnTestsHistory.ForeColor = System.Drawing.Color.White;
            btnTestsHistory.Location = new System.Drawing.Point(0, 53);
            btnTestsHistory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnTestsHistory.Name = "btnTestsHistory";
            btnTestsHistory.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnTestsHistory.Size = new System.Drawing.Size(265, 53);
            btnTestsHistory.TabIndex = 3;
            btnTestsHistory.Text = "History";
            btnTestsHistory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnTestsHistory.UseVisualStyleBackColor = true;
            btnTestsHistory.Click += btnTestsHistory_Click;
            // 
            // btnAddTest
            // 
            btnAddTest.Dock = System.Windows.Forms.DockStyle.Top;
            btnAddTest.FlatAppearance.BorderSize = 0;
            btnAddTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAddTest.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnAddTest.ForeColor = System.Drawing.Color.White;
            btnAddTest.Location = new System.Drawing.Point(0, 0);
            btnAddTest.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnAddTest.Name = "btnAddTest";
            btnAddTest.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnAddTest.Size = new System.Drawing.Size(265, 53);
            btnAddTest.TabIndex = 2;
            btnAddTest.Text = "Testing";
            btnAddTest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAddTest.UseVisualStyleBackColor = true;
            btnAddTest.Click += btnAddTest_Click;
            // 
            // btnLaboratory
            // 
            btnLaboratory.Dock = System.Windows.Forms.DockStyle.Top;
            btnLaboratory.FlatAppearance.BorderSize = 0;
            btnLaboratory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnLaboratory.Font = new System.Drawing.Font("Segoe UI", 10F);
            btnLaboratory.ForeColor = System.Drawing.Color.White;
            btnLaboratory.Image = (System.Drawing.Image)resources.GetObject("btnLaboratory.Image");
            btnLaboratory.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnLaboratory.Location = new System.Drawing.Point(0, 898);
            btnLaboratory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnLaboratory.Name = "btnLaboratory";
            btnLaboratory.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnLaboratory.Size = new System.Drawing.Size(265, 60);
            btnLaboratory.TabIndex = 19;
            btnLaboratory.Text = " Laboratory";
            btnLaboratory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnLaboratory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnLaboratory.UseVisualStyleBackColor = true;
            btnLaboratory.Click += btnLaboratory_Click;
            // 
            // panelPatientsSubMenu
            // 
            panelPatientsSubMenu.BackColor = System.Drawing.Color.FromArgb(0, 156, 208);
            panelPatientsSubMenu.Controls.Add(btnPatientRecord);
            panelPatientsSubMenu.Controls.Add(btnAddPatient);
            panelPatientsSubMenu.Controls.Add(btnPatientQueue);
            panelPatientsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            panelPatientsSubMenu.Location = new System.Drawing.Point(0, 735);
            panelPatientsSubMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelPatientsSubMenu.Name = "panelPatientsSubMenu";
            panelPatientsSubMenu.Size = new System.Drawing.Size(265, 163);
            panelPatientsSubMenu.TabIndex = 18;
            // 
            // btnPatientRecord
            // 
            btnPatientRecord.Dock = System.Windows.Forms.DockStyle.Top;
            btnPatientRecord.FlatAppearance.BorderSize = 0;
            btnPatientRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnPatientRecord.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnPatientRecord.ForeColor = System.Drawing.Color.White;
            btnPatientRecord.Location = new System.Drawing.Point(0, 106);
            btnPatientRecord.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnPatientRecord.Name = "btnPatientRecord";
            btnPatientRecord.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnPatientRecord.Size = new System.Drawing.Size(265, 53);
            btnPatientRecord.TabIndex = 5;
            btnPatientRecord.Text = "Patients Record";
            btnPatientRecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnPatientRecord.UseVisualStyleBackColor = true;
            btnPatientRecord.Click += btnPatientRecord_Click;
            // 
            // btnAddPatient
            // 
            btnAddPatient.Dock = System.Windows.Forms.DockStyle.Top;
            btnAddPatient.FlatAppearance.BorderSize = 0;
            btnAddPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAddPatient.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnAddPatient.ForeColor = System.Drawing.Color.White;
            btnAddPatient.Location = new System.Drawing.Point(0, 53);
            btnAddPatient.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnAddPatient.Name = "btnAddPatient";
            btnAddPatient.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnAddPatient.Size = new System.Drawing.Size(265, 53);
            btnAddPatient.TabIndex = 3;
            btnAddPatient.Text = "Add Patient";
            btnAddPatient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnAddPatient.UseVisualStyleBackColor = true;
            btnAddPatient.Click += btnAddPatient_Click;
            // 
            // btnPatientQueue
            // 
            btnPatientQueue.Dock = System.Windows.Forms.DockStyle.Top;
            btnPatientQueue.FlatAppearance.BorderSize = 0;
            btnPatientQueue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnPatientQueue.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnPatientQueue.ForeColor = System.Drawing.Color.White;
            btnPatientQueue.Location = new System.Drawing.Point(0, 0);
            btnPatientQueue.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnPatientQueue.Name = "btnPatientQueue";
            btnPatientQueue.Padding = new System.Windows.Forms.Padding(40, 0, 0, 0);
            btnPatientQueue.Size = new System.Drawing.Size(265, 53);
            btnPatientQueue.TabIndex = 2;
            btnPatientQueue.Text = "Patients Queue";
            btnPatientQueue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnPatientQueue.UseVisualStyleBackColor = true;
            btnPatientQueue.Click += btnPatientQueue_Click;
            // 
            // btnPatients
            // 
            btnPatients.Dock = System.Windows.Forms.DockStyle.Top;
            btnPatients.FlatAppearance.BorderSize = 0;
            btnPatients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnPatients.Font = new System.Drawing.Font("Segoe UI", 10F);
            btnPatients.ForeColor = System.Drawing.Color.White;
            btnPatients.Image = (System.Drawing.Image)resources.GetObject("btnPatients.Image");
            btnPatients.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnPatients.Location = new System.Drawing.Point(0, 675);
            btnPatients.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnPatients.Name = "btnPatients";
            btnPatients.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnPatients.Size = new System.Drawing.Size(265, 60);
            btnPatients.TabIndex = 17;
            btnPatients.Text = " Patients";
            btnPatients.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnPatients.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnPatients.UseVisualStyleBackColor = true;
            btnPatients.Click += btnPatients_Click;
            // 
            // panelDoctorsSubMenu
            // 
            panelDoctorsSubMenu.BackColor = System.Drawing.Color.FromArgb(0, 156, 208);
            panelDoctorsSubMenu.Controls.Add(btnSurgeon);
            panelDoctorsSubMenu.Controls.Add(btnLaboratoryTechnician);
            panelDoctorsSubMenu.Controls.Add(btnPharmacist);
            panelDoctorsSubMenu.Controls.Add(btnNurse);
            panelDoctorsSubMenu.Controls.Add(btnDoctor);
            panelDoctorsSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            panelDoctorsSubMenu.Location = new System.Drawing.Point(0, 296);
            panelDoctorsSubMenu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelDoctorsSubMenu.Name = "panelDoctorsSubMenu";
            panelDoctorsSubMenu.Size = new System.Drawing.Size(265, 379);
            panelDoctorsSubMenu.TabIndex = 16;
            // 
            // btnSurgeon
            // 
            btnSurgeon.Dock = System.Windows.Forms.DockStyle.Top;
            btnSurgeon.FlatAppearance.BorderSize = 0;
            btnSurgeon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnSurgeon.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnSurgeon.ForeColor = System.Drawing.Color.White;
            btnSurgeon.Image = (System.Drawing.Image)resources.GetObject("btnSurgeon.Image");
            btnSurgeon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnSurgeon.Location = new System.Drawing.Point(0, 212);
            btnSurgeon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnSurgeon.Name = "btnSurgeon";
            btnSurgeon.Size = new System.Drawing.Size(265, 53);
            btnSurgeon.TabIndex = 6;
            btnSurgeon.Text = "Surgeons";
            btnSurgeon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnSurgeon.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnSurgeon.UseVisualStyleBackColor = true;
            btnSurgeon.Click += btnSurgeon_Click;
            // 
            // btnLaboratoryTechnician
            // 
            btnLaboratoryTechnician.Dock = System.Windows.Forms.DockStyle.Top;
            btnLaboratoryTechnician.FlatAppearance.BorderSize = 0;
            btnLaboratoryTechnician.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnLaboratoryTechnician.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnLaboratoryTechnician.ForeColor = System.Drawing.Color.White;
            btnLaboratoryTechnician.Image = (System.Drawing.Image)resources.GetObject("btnLaboratoryTechnician.Image");
            btnLaboratoryTechnician.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnLaboratoryTechnician.Location = new System.Drawing.Point(0, 159);
            btnLaboratoryTechnician.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnLaboratoryTechnician.Name = "btnLaboratoryTechnician";
            btnLaboratoryTechnician.Size = new System.Drawing.Size(265, 53);
            btnLaboratoryTechnician.TabIndex = 5;
            btnLaboratoryTechnician.Text = "Laboratory technicians";
            btnLaboratoryTechnician.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnLaboratoryTechnician.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnLaboratoryTechnician.UseVisualStyleBackColor = true;
            btnLaboratoryTechnician.Click += btnLaboratoryTechnician_Click;
            // 
            // btnPharmacist
            // 
            btnPharmacist.Dock = System.Windows.Forms.DockStyle.Top;
            btnPharmacist.FlatAppearance.BorderSize = 0;
            btnPharmacist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnPharmacist.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnPharmacist.ForeColor = System.Drawing.Color.White;
            btnPharmacist.Image = (System.Drawing.Image)resources.GetObject("btnPharmacist.Image");
            btnPharmacist.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnPharmacist.Location = new System.Drawing.Point(0, 106);
            btnPharmacist.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnPharmacist.Name = "btnPharmacist";
            btnPharmacist.Size = new System.Drawing.Size(265, 53);
            btnPharmacist.TabIndex = 4;
            btnPharmacist.Text = "Pharmacists";
            btnPharmacist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnPharmacist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnPharmacist.UseVisualStyleBackColor = true;
            btnPharmacist.Click += btnPharmacist_Click;
            // 
            // btnNurse
            // 
            btnNurse.Dock = System.Windows.Forms.DockStyle.Top;
            btnNurse.FlatAppearance.BorderSize = 0;
            btnNurse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnNurse.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnNurse.ForeColor = System.Drawing.Color.White;
            btnNurse.Image = (System.Drawing.Image)resources.GetObject("btnNurse.Image");
            btnNurse.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnNurse.Location = new System.Drawing.Point(0, 53);
            btnNurse.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnNurse.Name = "btnNurse";
            btnNurse.RightToLeft = System.Windows.Forms.RightToLeft.No;
            btnNurse.Size = new System.Drawing.Size(265, 53);
            btnNurse.TabIndex = 3;
            btnNurse.Text = "Nurses";
            btnNurse.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnNurse.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnNurse.UseVisualStyleBackColor = true;
            btnNurse.Click += btnNurse_Click;
            // 
            // btnDoctor
            // 
            btnDoctor.Dock = System.Windows.Forms.DockStyle.Top;
            btnDoctor.FlatAppearance.BorderSize = 0;
            btnDoctor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDoctor.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnDoctor.ForeColor = System.Drawing.Color.White;
            btnDoctor.Image = (System.Drawing.Image)resources.GetObject("btnDoctor.Image");
            btnDoctor.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnDoctor.Location = new System.Drawing.Point(0, 0);
            btnDoctor.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnDoctor.Name = "btnDoctor";
            btnDoctor.Size = new System.Drawing.Size(265, 53);
            btnDoctor.TabIndex = 2;
            btnDoctor.Text = "Doctors";
            btnDoctor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnDoctor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnDoctor.UseVisualStyleBackColor = true;
            btnDoctor.Click += btnDoctor_Click;
            // 
            // btnEmployees
            // 
            btnEmployees.Dock = System.Windows.Forms.DockStyle.Top;
            btnEmployees.FlatAppearance.BorderSize = 0;
            btnEmployees.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnEmployees.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            btnEmployees.ForeColor = System.Drawing.Color.White;
            btnEmployees.Image = (System.Drawing.Image)resources.GetObject("btnEmployees.Image");
            btnEmployees.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnEmployees.Location = new System.Drawing.Point(0, 236);
            btnEmployees.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnEmployees.Name = "btnEmployees";
            btnEmployees.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnEmployees.Size = new System.Drawing.Size(265, 60);
            btnEmployees.TabIndex = 15;
            btnEmployees.Text = "Staff";
            btnEmployees.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnEmployees.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnEmployees.UseVisualStyleBackColor = true;
            btnEmployees.Click += btnEmployees_Click;
            // 
            // btnHome
            // 
            btnHome.Dock = System.Windows.Forms.DockStyle.Top;
            btnHome.FlatAppearance.BorderSize = 0;
            btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnHome.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            btnHome.ForeColor = System.Drawing.Color.White;
            btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnHome.Location = new System.Drawing.Point(0, 176);
            btnHome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnHome.Name = "btnHome";
            btnHome.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnHome.Size = new System.Drawing.Size(265, 60);
            btnHome.TabIndex = 14;
            btnHome.Text = "Home";
            btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnHome.UseVisualStyleBackColor = true;
            btnHome.Click += btnHome_Click;
            // 
            // btnExit
            // 
            btnExit.Dock = System.Windows.Forms.DockStyle.Bottom;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnExit.Font = new System.Drawing.Font("Segoe UI", 10F);
            btnExit.ForeColor = System.Drawing.Color.White;
            btnExit.Image = (System.Drawing.Image)resources.GetObject("btnExit.Image");
            btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnExit.Location = new System.Drawing.Point(0, 1354);
            btnExit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            btnExit.Name = "btnExit";
            btnExit.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            btnExit.Size = new System.Drawing.Size(265, 61);
            btnExit.TabIndex = 13;
            btnExit.Text = " Exit";
            btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // panelMenuLogo
            // 
            panelMenuLogo.BackgroundImage = (System.Drawing.Image)resources.GetObject("panelMenuLogo.BackgroundImage");
            panelMenuLogo.Dock = System.Windows.Forms.DockStyle.Top;
            panelMenuLogo.Location = new System.Drawing.Point(0, 0);
            panelMenuLogo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panelMenuLogo.Name = "panelMenuLogo";
            panelMenuLogo.Size = new System.Drawing.Size(265, 176);
            panelMenuLogo.TabIndex = 1;
            panelMenuLogo.MouseClick += panelMenuLogo_MouseClick;
            // 
            // panel
            // 
            panel.AutoScroll = true;
            panel.BackColor = System.Drawing.SystemColors.ButtonFace;
            panel.Dock = System.Windows.Forms.DockStyle.Fill;
            panel.Font = new System.Drawing.Font("Segoe UI", 9F);
            panel.Location = new System.Drawing.Point(286, 0);
            panel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            panel.Name = "panel";
            panel.Size = new System.Drawing.Size(941, 812);
            panel.TabIndex = 2;
            // 
            // MainForn
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1227, 812);
            Controls.Add(panel);
            Controls.Add(panelMenu);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            MinimumSize = new System.Drawing.Size(1243, 784);
            Name = "MainForn";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "HMS";
            panelMenu.ResumeLayout(false);
            panelUnitsSubMenu.ResumeLayout(false);
            panelCapitalSubMenu.ResumeLayout(false);
            panelLabSubMenu.ResumeLayout(false);
            panelPatientsSubMenu.ResumeLayout(false);
            panelDoctorsSubMenu.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelSideSlecectedShow;
        private System.Windows.Forms.Panel panelCapitalSubMenu;
        private System.Windows.Forms.Button btnCapitalRecord;
        private System.Windows.Forms.Button btnCapital;
        private System.Windows.Forms.Panel panelLabSubMenu;
        private System.Windows.Forms.Button btnTestsHistory;
        private System.Windows.Forms.Button btnAddTest;
        private System.Windows.Forms.Button btnLaboratory;
        private System.Windows.Forms.Panel panelPatientsSubMenu;
        private System.Windows.Forms.Button btnAddPatient;
        private System.Windows.Forms.Button btnPatientQueue;
        private System.Windows.Forms.Button btnPatients;
        private System.Windows.Forms.Panel panelDoctorsSubMenu;
        private System.Windows.Forms.Button btnSurgeon;
        private System.Windows.Forms.Button btnLaboratoryTechnician;
        private System.Windows.Forms.Button btnPharmacist;
        private System.Windows.Forms.Button btnNurse;
        private System.Windows.Forms.Button btnDoctor;
        private System.Windows.Forms.Button btnEmployees;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel panelMenuLogo;
        private System.Windows.Forms.Panel panel;

       private System.Windows.Forms.Panel panelUnitsSubMenu;
        private System.Windows.Forms.Button btnAddUnit;
        private System.Windows.Forms.Button btnUnits;
        private System.Windows.Forms.Button btnViewUnit;
        private System.Windows.Forms.Button btnPatientRecord;
    }
}

