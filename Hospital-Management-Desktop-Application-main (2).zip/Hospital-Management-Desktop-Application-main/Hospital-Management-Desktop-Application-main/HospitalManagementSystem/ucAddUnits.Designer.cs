﻿
namespace HospitalManagementSystem
{
    partial class ucAddUnits
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new System.Windows.Forms.Label();
            panel1 = new System.Windows.Forms.Panel();
            panelWard = new System.Windows.Forms.Panel();
            nudWardNo = new System.Windows.Forms.NumericUpDown();
            label12 = new System.Windows.Forms.Label();
            btnClearWardData = new System.Windows.Forms.Button();
            btnAddWardData = new System.Windows.Forms.Button();
            label15 = new System.Windows.Forms.Label();
            label23 = new System.Windows.Forms.Label();
            label24 = new System.Windows.Forms.Label();
            cbRating = new System.Windows.Forms.ComboBox();
            label25 = new System.Windows.Forms.Label();
            txtAddress = new System.Windows.Forms.RichTextBox();
            txtName1 = new System.Windows.Forms.TextBox();
            panelLaboratory = new System.Windows.Forms.Panel();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            btnClearLabortoryData = new System.Windows.Forms.Button();
            btnAddLaboratoryData = new System.Windows.Forms.Button();
            txtAddress2 = new System.Windows.Forms.RichTextBox();
            txtName2 = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            panelPharmacy = new System.Windows.Forms.Panel();
            label5 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            btnClearPharmacyData = new System.Windows.Forms.Button();
            btnAddPharmacyData = new System.Windows.Forms.Button();
            txtAddress3 = new System.Windows.Forms.RichTextBox();
            txtName3 = new System.Windows.Forms.TextBox();
            label8 = new System.Windows.Forms.Label();
            panelOperationTheatre = new System.Windows.Forms.Panel();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            btnClearOTData = new System.Windows.Forms.Button();
            btnAddOTData = new System.Windows.Forms.Button();
            txtAddress4 = new System.Windows.Forms.RichTextBox();
            txtName4 = new System.Windows.Forms.TextBox();
            label19 = new System.Windows.Forms.Label();
            panelBloodBank = new System.Windows.Forms.Panel();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            btnClearBloodBankData = new System.Windows.Forms.Button();
            label20 = new System.Windows.Forms.Label();
            btnAddBloodBankData = new System.Windows.Forms.Button();
            txtAddress5 = new System.Windows.Forms.RichTextBox();
            txtName5 = new System.Windows.Forms.TextBox();
            panelDepartment = new System.Windows.Forms.Panel();
            label6 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            btnClearDepartmentData = new System.Windows.Forms.Button();
            label16 = new System.Windows.Forms.Label();
            btnAddDepartmentData = new System.Windows.Forms.Button();
            txtAddress6 = new System.Windows.Forms.RichTextBox();
            txtName6 = new System.Windows.Forms.TextBox();
            panel2 = new System.Windows.Forms.Panel();
            panel1.SuspendLayout();
            panelWard.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudWardNo).BeginInit();
            panelLaboratory.SuspendLayout();
            panelPharmacy.SuspendLayout();
            panelOperationTheatre.SuspendLayout();
            panelBloodBank.SuspendLayout();
            panelDepartment.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Cursor = System.Windows.Forms.Cursors.No;
            label1.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label1.Location = new System.Drawing.Point(307, 10);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(219, 30);
            label1.TabIndex = 0;
            label1.Text = "Add Units Information";
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Dock = System.Windows.Forms.DockStyle.Top;
            panel1.Location = new System.Drawing.Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(824, 68);
            panel1.TabIndex = 4;
            // 
            // panelWard
            // 
            panelWard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panelWard.Controls.Add(nudWardNo);
            panelWard.Controls.Add(label12);
            panelWard.Controls.Add(btnClearWardData);
            panelWard.Controls.Add(btnAddWardData);
            panelWard.Controls.Add(label15);
            panelWard.Controls.Add(label23);
            panelWard.Controls.Add(label24);
            panelWard.Controls.Add(cbRating);
            panelWard.Controls.Add(label25);
            panelWard.Controls.Add(txtAddress);
            panelWard.Controls.Add(txtName1);
            panelWard.Dock = System.Windows.Forms.DockStyle.Top;
            panelWard.Location = new System.Drawing.Point(0, 68);
            panelWard.Name = "panelWard";
            panelWard.Size = new System.Drawing.Size(824, 187);
            panelWard.TabIndex = 5;
            panelWard.Paint += panelWard_Paint;
            // 
            // nudWardNo
            // 
            nudWardNo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            nudWardNo.Location = new System.Drawing.Point(179, 67);
            nudWardNo.Name = "nudWardNo";
            nudWardNo.Size = new System.Drawing.Size(120, 23);
            nudWardNo.TabIndex = 9;
            // 
            // label12
            // 
            label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("Segoe UI", 12F);
            label12.Location = new System.Drawing.Point(321, 43);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(58, 21);
            label12.TabIndex = 8;
            label12.Text = "Rating:";
            // 
            // btnClearWardData
            // 
            btnClearWardData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearWardData.Location = new System.Drawing.Point(715, 104);
            btnClearWardData.Name = "btnClearWardData";
            btnClearWardData.Size = new System.Drawing.Size(93, 31);
            btnClearWardData.TabIndex = 7;
            btnClearWardData.Text = "Clear...";
            btnClearWardData.UseVisualStyleBackColor = true;
            btnClearWardData.Click += btnClearWardData_Click;
            // 
            // btnAddWardData
            // 
            btnAddWardData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddWardData.Location = new System.Drawing.Point(715, 141);
            btnAddWardData.Name = "btnAddWardData";
            btnAddWardData.Size = new System.Drawing.Size(93, 31);
            btnAddWardData.TabIndex = 7;
            btnAddWardData.Text = "Add...";
            btnAddWardData.UseVisualStyleBackColor = true;
            btnAddWardData.Click += btnAddWardData_Click;
            // 
            // label15
            // 
            label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label15.AutoSize = true;
            label15.Font = new System.Drawing.Font("Segoe UI", 12F);
            label15.Location = new System.Drawing.Point(175, 43);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(75, 21);
            label15.TabIndex = 8;
            label15.Text = "Ward No.";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new System.Drawing.Font("Segoe UI", 12F);
            label23.Location = new System.Drawing.Point(13, 43);
            label23.Name = "label23";
            label23.Size = new System.Drawing.Size(55, 21);
            label23.TabIndex = 8;
            label23.Text = "Name:";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new System.Drawing.Font("Segoe UI", 12F);
            label24.Location = new System.Drawing.Point(13, 96);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(69, 21);
            label24.TabIndex = 8;
            label24.Text = "Address:";
            // 
            // cbRating
            // 
            cbRating.Anchor = System.Windows.Forms.AnchorStyles.Top;
            cbRating.FormattingEnabled = true;
            cbRating.Location = new System.Drawing.Point(325, 67);
            cbRating.Name = "cbRating";
            cbRating.Size = new System.Drawing.Size(109, 23);
            cbRating.TabIndex = 6;
            // 
            // label25
            // 
            label25.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label25.AutoSize = true;
            label25.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label25.Location = new System.Drawing.Point(402, 0);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(62, 30);
            label25.TabIndex = 2;
            label25.Text = "Ward";
            // 
            // txtAddress
            // 
            txtAddress.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress.Location = new System.Drawing.Point(17, 120);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new System.Drawing.Size(417, 52);
            txtAddress.TabIndex = 5;
            txtAddress.Text = "";
            // 
            // txtName1
            // 
            txtName1.Location = new System.Drawing.Point(17, 67);
            txtName1.Name = "txtName1";
            txtName1.Size = new System.Drawing.Size(136, 23);
            txtName1.TabIndex = 1;
            // 
            // panelLaboratory
            // 
            panelLaboratory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panelLaboratory.Controls.Add(label2);
            panelLaboratory.Controls.Add(label3);
            panelLaboratory.Controls.Add(btnClearLabortoryData);
            panelLaboratory.Controls.Add(btnAddLaboratoryData);
            panelLaboratory.Controls.Add(txtAddress2);
            panelLaboratory.Controls.Add(txtName2);
            panelLaboratory.Controls.Add(label4);
            panelLaboratory.Dock = System.Windows.Forms.DockStyle.Top;
            panelLaboratory.Location = new System.Drawing.Point(0, 255);
            panelLaboratory.Name = "panelLaboratory";
            panelLaboratory.Size = new System.Drawing.Size(824, 187);
            panelLaboratory.TabIndex = 6;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            label2.Location = new System.Drawing.Point(13, 43);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(55, 21);
            label2.TabIndex = 8;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Segoe UI", 12F);
            label3.Location = new System.Drawing.Point(14, 96);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(69, 21);
            label3.TabIndex = 8;
            label3.Text = "Address:";
            // 
            // btnClearLabortoryData
            // 
            btnClearLabortoryData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearLabortoryData.Location = new System.Drawing.Point(715, 104);
            btnClearLabortoryData.Name = "btnClearLabortoryData";
            btnClearLabortoryData.Size = new System.Drawing.Size(93, 31);
            btnClearLabortoryData.TabIndex = 7;
            btnClearLabortoryData.Text = "Clear...";
            btnClearLabortoryData.UseVisualStyleBackColor = true;
            btnClearLabortoryData.Click += btnClearLabortoryData_Click;
            // 
            // btnAddLaboratoryData
            // 
            btnAddLaboratoryData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddLaboratoryData.Location = new System.Drawing.Point(715, 141);
            btnAddLaboratoryData.Name = "btnAddLaboratoryData";
            btnAddLaboratoryData.Size = new System.Drawing.Size(93, 31);
            btnAddLaboratoryData.TabIndex = 7;
            btnAddLaboratoryData.Text = "Add...";
            btnAddLaboratoryData.UseVisualStyleBackColor = true;
            btnAddLaboratoryData.Click += btnAddLaboratoryData_Click;
            // 
            // txtAddress2
            // 
            txtAddress2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress2.Location = new System.Drawing.Point(17, 120);
            txtAddress2.Name = "txtAddress2";
            txtAddress2.Size = new System.Drawing.Size(417, 52);
            txtAddress2.TabIndex = 5;
            txtAddress2.Text = "";
            // 
            // txtName2
            // 
            txtName2.Location = new System.Drawing.Point(17, 67);
            txtName2.Name = "txtName2";
            txtName2.Size = new System.Drawing.Size(215, 23);
            txtName2.TabIndex = 1;
            // 
            // label4
            // 
            label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label4.Location = new System.Drawing.Point(378, -1);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(112, 30);
            label4.TabIndex = 2;
            label4.Text = "Laboratory";
            // 
            // panelPharmacy
            // 
            panelPharmacy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panelPharmacy.Controls.Add(label5);
            panelPharmacy.Controls.Add(label7);
            panelPharmacy.Controls.Add(btnClearPharmacyData);
            panelPharmacy.Controls.Add(btnAddPharmacyData);
            panelPharmacy.Controls.Add(txtAddress3);
            panelPharmacy.Controls.Add(txtName3);
            panelPharmacy.Controls.Add(label8);
            panelPharmacy.Dock = System.Windows.Forms.DockStyle.Top;
            panelPharmacy.Location = new System.Drawing.Point(0, 442);
            panelPharmacy.Name = "panelPharmacy";
            panelPharmacy.Size = new System.Drawing.Size(824, 187);
            panelPharmacy.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Segoe UI", 12F);
            label5.Location = new System.Drawing.Point(14, 46);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(55, 21);
            label5.TabIndex = 8;
            label5.Text = "Name:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Segoe UI", 12F);
            label7.Location = new System.Drawing.Point(15, 96);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(69, 21);
            label7.TabIndex = 8;
            label7.Text = "Address:";
            // 
            // btnClearPharmacyData
            // 
            btnClearPharmacyData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearPharmacyData.Location = new System.Drawing.Point(715, 104);
            btnClearPharmacyData.Name = "btnClearPharmacyData";
            btnClearPharmacyData.Size = new System.Drawing.Size(93, 31);
            btnClearPharmacyData.TabIndex = 7;
            btnClearPharmacyData.Text = "Clear...";
            btnClearPharmacyData.UseVisualStyleBackColor = true;
            btnClearPharmacyData.Click += btnClearPharmacyData_Click;
            // 
            // btnAddPharmacyData
            // 
            btnAddPharmacyData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddPharmacyData.Location = new System.Drawing.Point(715, 141);
            btnAddPharmacyData.Name = "btnAddPharmacyData";
            btnAddPharmacyData.Size = new System.Drawing.Size(93, 31);
            btnAddPharmacyData.TabIndex = 7;
            btnAddPharmacyData.Text = "Add...";
            btnAddPharmacyData.UseVisualStyleBackColor = true;
            btnAddPharmacyData.Click += btnAddPharmacyData_Click;
            // 
            // txtAddress3
            // 
            txtAddress3.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress3.Location = new System.Drawing.Point(18, 120);
            txtAddress3.Name = "txtAddress3";
            txtAddress3.Size = new System.Drawing.Size(417, 52);
            txtAddress3.TabIndex = 5;
            txtAddress3.Text = "";
            // 
            // txtName3
            // 
            txtName3.Location = new System.Drawing.Point(18, 70);
            txtName3.Name = "txtName3";
            txtName3.Size = new System.Drawing.Size(215, 23);
            txtName3.TabIndex = 1;
            // 
            // label8
            // 
            label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label8.Location = new System.Drawing.Point(386, -1);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(104, 30);
            label8.TabIndex = 2;
            label8.Text = "Pharmacy";
            // 
            // panelOperationTheatre
            // 
            panelOperationTheatre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panelOperationTheatre.Controls.Add(label10);
            panelOperationTheatre.Controls.Add(label11);
            panelOperationTheatre.Controls.Add(btnClearOTData);
            panelOperationTheatre.Controls.Add(btnAddOTData);
            panelOperationTheatre.Controls.Add(txtAddress4);
            panelOperationTheatre.Controls.Add(txtName4);
            panelOperationTheatre.Controls.Add(label19);
            panelOperationTheatre.Dock = System.Windows.Forms.DockStyle.Top;
            panelOperationTheatre.Location = new System.Drawing.Point(0, 629);
            panelOperationTheatre.Name = "panelOperationTheatre";
            panelOperationTheatre.Size = new System.Drawing.Size(824, 187);
            panelOperationTheatre.TabIndex = 9;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Segoe UI", 12F);
            label10.Location = new System.Drawing.Point(14, 46);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(55, 21);
            label10.TabIndex = 8;
            label10.Text = "Name:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Segoe UI", 12F);
            label11.Location = new System.Drawing.Point(15, 96);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(69, 21);
            label11.TabIndex = 8;
            label11.Text = "Address:";
            // 
            // btnClearOTData
            // 
            btnClearOTData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearOTData.Location = new System.Drawing.Point(715, 104);
            btnClearOTData.Name = "btnClearOTData";
            btnClearOTData.Size = new System.Drawing.Size(93, 31);
            btnClearOTData.TabIndex = 7;
            btnClearOTData.Text = "Clear...";
            btnClearOTData.UseVisualStyleBackColor = true;
            btnClearOTData.Click += btnClearOTData_Click;
            // 
            // btnAddOTData
            // 
            btnAddOTData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddOTData.Location = new System.Drawing.Point(715, 141);
            btnAddOTData.Name = "btnAddOTData";
            btnAddOTData.Size = new System.Drawing.Size(93, 31);
            btnAddOTData.TabIndex = 7;
            btnAddOTData.Text = "Add...";
            btnAddOTData.UseVisualStyleBackColor = true;
            btnAddOTData.Click += btnAddOTData_Click;
            // 
            // txtAddress4
            // 
            txtAddress4.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress4.Location = new System.Drawing.Point(18, 120);
            txtAddress4.Name = "txtAddress4";
            txtAddress4.Size = new System.Drawing.Size(417, 52);
            txtAddress4.TabIndex = 5;
            txtAddress4.Text = "";
            // 
            // txtName4
            // 
            txtName4.Location = new System.Drawing.Point(18, 70);
            txtName4.Name = "txtName4";
            txtName4.Size = new System.Drawing.Size(215, 23);
            txtName4.TabIndex = 1;
            // 
            // label19
            // 
            label19.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label19.AutoSize = true;
            label19.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label19.Location = new System.Drawing.Point(352, 0);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(182, 30);
            label19.TabIndex = 2;
            label19.Text = "Operation Theater";
            // 
            // panelBloodBank
            // 
            panelBloodBank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panelBloodBank.Controls.Add(label13);
            panelBloodBank.Controls.Add(label14);
            panelBloodBank.Controls.Add(btnClearBloodBankData);
            panelBloodBank.Controls.Add(label20);
            panelBloodBank.Controls.Add(btnAddBloodBankData);
            panelBloodBank.Controls.Add(txtAddress5);
            panelBloodBank.Controls.Add(txtName5);
            panelBloodBank.Dock = System.Windows.Forms.DockStyle.Top;
            panelBloodBank.Location = new System.Drawing.Point(0, 816);
            panelBloodBank.Name = "panelBloodBank";
            panelBloodBank.Size = new System.Drawing.Size(824, 187);
            panelBloodBank.TabIndex = 9;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new System.Drawing.Font("Segoe UI", 12F);
            label13.Location = new System.Drawing.Point(13, 46);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(55, 21);
            label13.TabIndex = 8;
            label13.Text = "Name:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("Segoe UI", 12F);
            label14.Location = new System.Drawing.Point(15, 96);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(69, 21);
            label14.TabIndex = 8;
            label14.Text = "Address:";
            // 
            // btnClearBloodBankData
            // 
            btnClearBloodBankData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearBloodBankData.Location = new System.Drawing.Point(712, 102);
            btnClearBloodBankData.Name = "btnClearBloodBankData";
            btnClearBloodBankData.Size = new System.Drawing.Size(93, 31);
            btnClearBloodBankData.TabIndex = 7;
            btnClearBloodBankData.Text = "Clear...";
            btnClearBloodBankData.UseVisualStyleBackColor = true;
            btnClearBloodBankData.Click += btnClearBloodBankData_Click;
            // 
            // label20
            // 
            label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label20.AutoSize = true;
            label20.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label20.Location = new System.Drawing.Point(380, 2);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(111, 30);
            label20.TabIndex = 2;
            label20.Text = "BloodBank";
            // 
            // btnAddBloodBankData
            // 
            btnAddBloodBankData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddBloodBankData.Location = new System.Drawing.Point(712, 139);
            btnAddBloodBankData.Name = "btnAddBloodBankData";
            btnAddBloodBankData.Size = new System.Drawing.Size(93, 33);
            btnAddBloodBankData.TabIndex = 7;
            btnAddBloodBankData.Text = "Add...";
            btnAddBloodBankData.UseVisualStyleBackColor = true;
            btnAddBloodBankData.Click += btnAddBloodBankData_Click;
            // 
            // txtAddress5
            // 
            txtAddress5.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress5.Location = new System.Drawing.Point(18, 120);
            txtAddress5.Name = "txtAddress5";
            txtAddress5.Size = new System.Drawing.Size(417, 52);
            txtAddress5.TabIndex = 5;
            txtAddress5.Text = "";
            // 
            // txtName5
            // 
            txtName5.Location = new System.Drawing.Point(18, 70);
            txtName5.Name = "txtName5";
            txtName5.Size = new System.Drawing.Size(215, 23);
            txtName5.TabIndex = 1;
            // 
            // panelDepartment
            // 
            panelDepartment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panelDepartment.Controls.Add(label6);
            panelDepartment.Controls.Add(label9);
            panelDepartment.Controls.Add(btnClearDepartmentData);
            panelDepartment.Controls.Add(label16);
            panelDepartment.Controls.Add(btnAddDepartmentData);
            panelDepartment.Controls.Add(txtAddress6);
            panelDepartment.Controls.Add(txtName6);
            panelDepartment.Dock = System.Windows.Forms.DockStyle.Top;
            panelDepartment.Location = new System.Drawing.Point(0, 1003);
            panelDepartment.Name = "panelDepartment";
            panelDepartment.Size = new System.Drawing.Size(824, 187);
            panelDepartment.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Segoe UI", 12F);
            label6.Location = new System.Drawing.Point(14, 47);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(55, 21);
            label6.TabIndex = 8;
            label6.Text = "Name:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("Segoe UI", 12F);
            label9.Location = new System.Drawing.Point(15, 97);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(69, 21);
            label9.TabIndex = 8;
            label9.Text = "Address:";
            // 
            // btnClearDepartmentData
            // 
            btnClearDepartmentData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearDepartmentData.Location = new System.Drawing.Point(712, 88);
            btnClearDepartmentData.Name = "btnClearDepartmentData";
            btnClearDepartmentData.Size = new System.Drawing.Size(93, 31);
            btnClearDepartmentData.TabIndex = 7;
            btnClearDepartmentData.Text = "Clear...";
            btnClearDepartmentData.UseVisualStyleBackColor = true;
            btnClearDepartmentData.Click += btnClearDepartmentData_Click;
            // 
            // label16
            // 
            label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label16.AutoSize = true;
            label16.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label16.Location = new System.Drawing.Point(373, 0);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(124, 30);
            label16.TabIndex = 2;
            label16.Text = "Department";
            // 
            // btnAddDepartmentData
            // 
            btnAddDepartmentData.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddDepartmentData.Location = new System.Drawing.Point(712, 125);
            btnAddDepartmentData.Name = "btnAddDepartmentData";
            btnAddDepartmentData.Size = new System.Drawing.Size(93, 33);
            btnAddDepartmentData.TabIndex = 7;
            btnAddDepartmentData.Text = "Add...";
            btnAddDepartmentData.UseVisualStyleBackColor = true;
            btnAddDepartmentData.Click += btnAddDepartmentData_Click;
            // 
            // txtAddress6
            // 
            txtAddress6.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress6.Location = new System.Drawing.Point(18, 121);
            txtAddress6.Name = "txtAddress6";
            txtAddress6.Size = new System.Drawing.Size(417, 52);
            txtAddress6.TabIndex = 5;
            txtAddress6.Text = "";
            // 
            // txtName6
            // 
            txtName6.Location = new System.Drawing.Point(17, 71);
            txtName6.Name = "txtName6";
            txtName6.Size = new System.Drawing.Size(215, 23);
            txtName6.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Dock = System.Windows.Forms.DockStyle.Top;
            panel2.Location = new System.Drawing.Point(0, 1190);
            panel2.Name = "panel2";
            panel2.Size = new System.Drawing.Size(824, 187);
            panel2.TabIndex = 4;
            // 
            // ucAddUnits
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            AutoScroll = true;
            AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            Controls.Add(panel2);
            Controls.Add(panelDepartment);
            Controls.Add(panelBloodBank);
            Controls.Add(panelOperationTheatre);
            Controls.Add(panelPharmacy);
            Controls.Add(panelLaboratory);
            Controls.Add(panelWard);
            Controls.Add(panel1);
            Name = "ucAddUnits";
            Size = new System.Drawing.Size(824, 1498);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panelWard.ResumeLayout(false);
            panelWard.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudWardNo).EndInit();
            panelLaboratory.ResumeLayout(false);
            panelLaboratory.PerformLayout();
            panelPharmacy.ResumeLayout(false);
            panelPharmacy.PerformLayout();
            panelOperationTheatre.ResumeLayout(false);
            panelOperationTheatre.PerformLayout();
            panelBloodBank.ResumeLayout(false);
            panelBloodBank.PerformLayout();
            panelDepartment.ResumeLayout(false);
            panelDepartment.PerformLayout();
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelWard;
        private System.Windows.Forms.NumericUpDown nudWardNo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnClearWardData;
        private System.Windows.Forms.Button btnAddWardData;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cbRating;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RichTextBox txtAddress;
        private System.Windows.Forms.TextBox txtName1;
        private System.Windows.Forms.Panel panelLaboratory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnClearLabortoryData;
        private System.Windows.Forms.Button btnAddLaboratoryData;
        private System.Windows.Forms.RichTextBox txtAddress2;
        private System.Windows.Forms.TextBox txtName2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelPharmacy;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnClearPharmacyData;
        private System.Windows.Forms.Button btnAddPharmacyData;
        private System.Windows.Forms.RichTextBox txtAddress3;
        private System.Windows.Forms.TextBox txtName3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panelOperationTheatre;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnClearOTData;
        private System.Windows.Forms.Button btnAddOTData;
        private System.Windows.Forms.RichTextBox txtAddress4;
        private System.Windows.Forms.TextBox txtName4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panelBloodBank;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnClearBloodBankData;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnAddBloodBankData;
        private System.Windows.Forms.RichTextBox txtAddress5;
        private System.Windows.Forms.TextBox txtName5;
        private System.Windows.Forms.Panel panelDepartment;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnClearDepartmentData;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnAddDepartmentData;
        private System.Windows.Forms.RichTextBox txtAddress6;
        private System.Windows.Forms.TextBox txtName6;
        private System.Windows.Forms.Panel panel2;
    }
}
