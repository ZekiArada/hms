﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagementSystem
{
    public class csTools
    {
        public String Name { get; set; }
        public String Description { get; set; }
        public double Price { get; set; }


    }
}
