﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagementSystem
{
    class csAdmin:csAdministrativeStaff
    {
        public void AddDoctor (){ }
        public void ViewDoctor() { }
        public void SearchDoctor() { }
        public void DeleteDoctor() { }
        public void UpdateDoctor() { }
        public void AddLabTechnician() { }
        public void ViewLabTechnician() { }
        public void SearchLabTechnician() { }
        public void DeleteLabTechnician() { }
        public void UpdateLabTechnician() { }
        public void AddNurse() { }
        public void ViewNurse() { }
        public void SearchNurse() { }
        public void DeleteNurse() { }
        public void UpdateNurse() { }
        public void AddReceptionist() { }
        public void ViewReceptionist() { }
        public void SearchReceptionist() { }
        public void DeleteReceptionist() { }
        public void UpdateReceptionist() { }
        public void AddOtherStaff() { }
        public void ViewOtherStaff() { }
        public void SearchOtherStaff() { }
        public void DeleteOtherStaff() { }
        public void UpdateOtherStaff() { }
        public void AddPharmacist() { }
        public void ViewPharmacist() { }
        public void SearchPharmacist() { }
        public void DeletePharmacist() { }
        public void UpdatePharmacist() { }
        public void AddWard() { }
        public void AddPharmacy() { }
        public void AddLaboratory() { }
        public void AddOperationTheater() { }
        public void AddDepartment() { }
        public void AddBloodBank() { }

    }
}
