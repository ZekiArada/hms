﻿
namespace HospitalManagementSystem
{
    partial class ucAddSurgeon
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new System.Windows.Forms.Panel();
            lbInvalidInput = new System.Windows.Forms.Label();
            btnCancel = new System.Windows.Forms.Button();
            btnClearInput = new System.Windows.Forms.Button();
            btnAddInput = new System.Windows.Forms.Button();
            dtpWHend = new System.Windows.Forms.DateTimePicker();
            dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            dtpWHstart = new System.Windows.Forms.DateTimePicker();
            rbtnFemale = new System.Windows.Forms.RadioButton();
            rbtnMale = new System.Windows.Forms.RadioButton();
            nudEcperiance = new System.Windows.Forms.NumericUpDown();
            nudSalary = new System.Windows.Forms.NumericUpDown();
            txtAddress = new System.Windows.Forms.RichTextBox();
            cbQualification = new System.Windows.Forms.ComboBox();
            cbSpecialization = new System.Windows.Forms.ComboBox();
            cbDepartment = new System.Windows.Forms.ComboBox();
            txtPhoneNo = new System.Windows.Forms.MaskedTextBox();
            txtPassword = new System.Windows.Forms.TextBox();
            txtEmail = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            txtName = new System.Windows.Forms.TextBox();
            label15 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            txtCnic = new System.Windows.Forms.MaskedTextBox();
            label1 = new System.Windows.Forms.Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudEcperiance).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudSalary).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            panel1.Controls.Add(lbInvalidInput);
            panel1.Controls.Add(btnCancel);
            panel1.Controls.Add(btnClearInput);
            panel1.Controls.Add(btnAddInput);
            panel1.Controls.Add(dtpWHend);
            panel1.Controls.Add(dtpDateOfBirth);
            panel1.Controls.Add(dtpWHstart);
            panel1.Controls.Add(rbtnFemale);
            panel1.Controls.Add(rbtnMale);
            panel1.Controls.Add(nudEcperiance);
            panel1.Controls.Add(nudSalary);
            panel1.Controls.Add(txtAddress);
            panel1.Controls.Add(cbQualification);
            panel1.Controls.Add(cbSpecialization);
            panel1.Controls.Add(cbDepartment);
            panel1.Controls.Add(txtPhoneNo);
            panel1.Controls.Add(txtPassword);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(txtName);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(label14);
            panel1.Controls.Add(label13);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label16);
            panel1.Controls.Add(label17);
            panel1.Controls.Add(label12);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(txtCnic);
            panel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            panel1.Location = new System.Drawing.Point(19, 59);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(787, 488);
            panel1.TabIndex = 8;
            panel1.Paint += panel1_Paint;
            // 
            // lbInvalidInput
            // 
            lbInvalidInput.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            lbInvalidInput.AutoSize = true;
            lbInvalidInput.ForeColor = System.Drawing.Color.Red;
            lbInvalidInput.Location = new System.Drawing.Point(686, 418);
            lbInvalidInput.Name = "lbInvalidInput";
            lbInvalidInput.Size = new System.Drawing.Size(73, 15);
            lbInvalidInput.TabIndex = 16;
            lbInvalidInput.Text = "Invalid Input";
            // 
            // btnCancel
            // 
            btnCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnCancel.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnCancel.Location = new System.Drawing.Point(488, 436);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(90, 30);
            btnCancel.TabIndex = 15;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnClearInput
            // 
            btnClearInput.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnClearInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnClearInput.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnClearInput.Location = new System.Drawing.Point(584, 436);
            btnClearInput.Name = "btnClearInput";
            btnClearInput.Size = new System.Drawing.Size(90, 30);
            btnClearInput.TabIndex = 15;
            btnClearInput.Text = "Clear";
            btnClearInput.UseVisualStyleBackColor = true;
            btnClearInput.Click += btnClearInput_Click;
            // 
            // btnAddInput
            // 
            btnAddInput.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            btnAddInput.BackColor = System.Drawing.Color.Gainsboro;
            btnAddInput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAddInput.Font = new System.Drawing.Font("Segoe UI", 9F);
            btnAddInput.Location = new System.Drawing.Point(680, 436);
            btnAddInput.Name = "btnAddInput";
            btnAddInput.Size = new System.Drawing.Size(90, 30);
            btnAddInput.TabIndex = 14;
            btnAddInput.Text = "Add";
            btnAddInput.UseVisualStyleBackColor = false;
            btnAddInput.Click += btnAddInput_Click;
            // 
            // dtpWHend
            // 
            dtpWHend.Font = new System.Drawing.Font("Segoe UI", 9F);
            dtpWHend.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            dtpWHend.Location = new System.Drawing.Point(275, 218);
            dtpWHend.Name = "dtpWHend";
            dtpWHend.Size = new System.Drawing.Size(84, 23);
            dtpWHend.TabIndex = 0;
            dtpWHend.Value = new System.DateTime(2021, 5, 22, 0, 0, 0, 0);
            // 
            // dtpDateOfBirth
            // 
            dtpDateOfBirth.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            dtpDateOfBirth.Font = new System.Drawing.Font("Segoe UI", 9F);
            dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            dtpDateOfBirth.Location = new System.Drawing.Point(600, 38);
            dtpDateOfBirth.Name = "dtpDateOfBirth";
            dtpDateOfBirth.Size = new System.Drawing.Size(170, 23);
            dtpDateOfBirth.TabIndex = 11;
            dtpDateOfBirth.Value = new System.DateTime(2021, 5, 22, 0, 0, 0, 0);
            // 
            // dtpWHstart
            // 
            dtpWHstart.Font = new System.Drawing.Font("Segoe UI", 9F);
            dtpWHstart.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            dtpWHstart.Location = new System.Drawing.Point(169, 218);
            dtpWHstart.Name = "dtpWHstart";
            dtpWHstart.Size = new System.Drawing.Size(83, 23);
            dtpWHstart.TabIndex = 11;
            dtpWHstart.Value = new System.DateTime(2021, 5, 22, 0, 0, 0, 0);
            // 
            // rbtnFemale
            // 
            rbtnFemale.Anchor = System.Windows.Forms.AnchorStyles.Top;
            rbtnFemale.AutoSize = true;
            rbtnFemale.Font = new System.Drawing.Font("Segoe UI", 9F);
            rbtnFemale.Location = new System.Drawing.Point(463, 175);
            rbtnFemale.Name = "rbtnFemale";
            rbtnFemale.Size = new System.Drawing.Size(63, 19);
            rbtnFemale.TabIndex = 10;
            rbtnFemale.TabStop = true;
            rbtnFemale.Text = "Female";
            rbtnFemale.UseVisualStyleBackColor = true;
            rbtnFemale.CheckedChanged += this.rbtnFemale_CheckedChanged;
            // 
            // rbtnMale
            // 
            rbtnMale.Anchor = System.Windows.Forms.AnchorStyles.Top;
            rbtnMale.AutoSize = true;
            rbtnMale.Font = new System.Drawing.Font("Segoe UI", 9F);
            rbtnMale.Location = new System.Drawing.Point(463, 149);
            rbtnMale.Name = "rbtnMale";
            rbtnMale.Size = new System.Drawing.Size(51, 19);
            rbtnMale.TabIndex = 10;
            rbtnMale.TabStop = true;
            rbtnMale.Text = "Male";
            rbtnMale.UseVisualStyleBackColor = true;
            // 
            // nudEcperiance
            // 
            nudEcperiance.Anchor = System.Windows.Forms.AnchorStyles.Top;
            nudEcperiance.Font = new System.Drawing.Font("Segoe UI", 9F);
            nudEcperiance.Location = new System.Drawing.Point(290, 159);
            nudEcperiance.Name = "nudEcperiance";
            nudEcperiance.Size = new System.Drawing.Size(73, 23);
            nudEcperiance.TabIndex = 9;
            // 
            // nudSalary
            // 
            nudSalary.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            nudSalary.Font = new System.Drawing.Font("Segoe UI", 9F);
            nudSalary.Increment = new decimal(new int[] { 5000, 0, 0, 0 });
            nudSalary.Location = new System.Drawing.Point(654, 159);
            nudSalary.Maximum = new decimal(new int[] { 999999999, 0, 0, 0 });
            nudSalary.Name = "nudSalary";
            nudSalary.Size = new System.Drawing.Size(116, 23);
            nudSalary.TabIndex = 9;
            // 
            // txtAddress
            // 
            txtAddress.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            txtAddress.Location = new System.Drawing.Point(11, 284);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new System.Drawing.Size(759, 114);
            txtAddress.TabIndex = 3;
            txtAddress.Text = "";
            // 
            // cbQualification
            // 
            cbQualification.Anchor = System.Windows.Forms.AnchorStyles.Top;
            cbQualification.Font = new System.Drawing.Font("Segoe UI", 9F);
            cbQualification.FormattingEnabled = true;
            cbQualification.Items.AddRange(new object[] { "Department of Neurology", "Department of Cardiology" });
            cbQualification.Location = new System.Drawing.Point(403, 103);
            cbQualification.Name = "cbQualification";
            cbQualification.Size = new System.Drawing.Size(160, 23);
            cbQualification.TabIndex = 2;
            // 
            // cbSpecialization
            // 
            cbSpecialization.Font = new System.Drawing.Font("Segoe UI", 9F);
            cbSpecialization.FormattingEnabled = true;
            cbSpecialization.Items.AddRange(new object[] { "Department of Neurology", "Department of Cardiology" });
            cbSpecialization.Location = new System.Drawing.Point(8, 167);
            cbSpecialization.Name = "cbSpecialization";
            cbSpecialization.Size = new System.Drawing.Size(160, 23);
            cbSpecialization.TabIndex = 2;
            // 
            // cbDepartment
            // 
            cbDepartment.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            cbDepartment.Font = new System.Drawing.Font("Segoe UI", 9F);
            cbDepartment.FormattingEnabled = true;
            cbDepartment.Items.AddRange(new object[] { "Department of Neurology", "Department of Cardiology" });
            cbDepartment.Location = new System.Drawing.Point(600, 103);
            cbDepartment.Name = "cbDepartment";
            cbDepartment.Size = new System.Drawing.Size(170, 23);
            cbDepartment.TabIndex = 2;
            // 
            // txtPhoneNo
            // 
            txtPhoneNo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            txtPhoneNo.Font = new System.Drawing.Font("Segoe UI", 9F);
            txtPhoneNo.Location = new System.Drawing.Point(401, 38);
            txtPhoneNo.Mask = "0000-0000000";
            txtPhoneNo.Name = "txtPhoneNo";
            txtPhoneNo.Size = new System.Drawing.Size(162, 23);
            txtPhoneNo.TabIndex = 1;
            // 
            // txtPassword
            // 
            txtPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            txtPassword.Font = new System.Drawing.Font("Segoe UI", 9F);
            txtPassword.Location = new System.Drawing.Point(204, 103);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new System.Drawing.Size(159, 23);
            txtPassword.TabIndex = 0;
            // 
            // txtEmail
            // 
            txtEmail.Font = new System.Drawing.Font("Segoe UI", 9F);
            txtEmail.Location = new System.Drawing.Point(11, 103);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new System.Drawing.Size(157, 23);
            txtEmail.TabIndex = 0;
            // 
            // label3
            // 
            label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Segoe UI", 12F);
            label3.Location = new System.Drawing.Point(1074, 24);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(0, 21);
            label3.TabIndex = 0;
            // 
            // label8
            // 
            label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("Segoe UI", 12F);
            label8.Location = new System.Drawing.Point(200, 79);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(79, 21);
            label8.TabIndex = 0;
            label8.Text = "Password:";
            // 
            // txtName
            // 
            txtName.Font = new System.Drawing.Font("Segoe UI", 9F);
            txtName.Location = new System.Drawing.Point(11, 38);
            txtName.Name = "txtName";
            txtName.Size = new System.Drawing.Size(157, 23);
            txtName.TabIndex = 0;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new System.Drawing.Font("Segoe UI", 9F);
            label15.Location = new System.Drawing.Point(255, 223);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(18, 15);
            label15.TabIndex = 0;
            label15.Text = "to";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("Segoe UI", 9F);
            label14.Location = new System.Drawing.Point(132, 223);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(35, 15);
            label14.TabIndex = 0;
            label14.Text = "From";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new System.Drawing.Font("Segoe UI", 12F);
            label13.Location = new System.Drawing.Point(8, 218);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(118, 21);
            label13.TabIndex = 0;
            label13.Text = "Working Hours:";
            // 
            // label10
            // 
            label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("Segoe UI", 12F);
            label10.Location = new System.Drawing.Point(398, 160);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(64, 21);
            label10.TabIndex = 0;
            label10.Text = "Gender:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("Segoe UI", 12F);
            label9.Location = new System.Drawing.Point(6, 260);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(69, 21);
            label9.TabIndex = 0;
            label9.Text = "Address:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Segoe UI", 12F);
            label4.Location = new System.Drawing.Point(6, 79);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(51, 21);
            label4.TabIndex = 0;
            label4.Text = "Email:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new System.Drawing.Font("Segoe UI", 12F);
            label16.Location = new System.Drawing.Point(6, 143);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(108, 21);
            label16.TabIndex = 0;
            label16.Text = "Specialization:";
            // 
            // label17
            // 
            label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label17.AutoSize = true;
            label17.Font = new System.Drawing.Font("Segoe UI", 12F);
            label17.Location = new System.Drawing.Point(398, 79);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(101, 21);
            label17.TabIndex = 0;
            label17.Text = "Qualification:";
            // 
            // label12
            // 
            label12.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("Segoe UI", 12F);
            label12.Location = new System.Drawing.Point(595, 79);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(90, 21);
            label12.TabIndex = 0;
            label12.Text = "Depatment:";
            // 
            // label18
            // 
            label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label18.AutoSize = true;
            label18.Font = new System.Drawing.Font("Segoe UI", 12F);
            label18.Location = new System.Drawing.Point(200, 160);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(87, 21);
            label18.TabIndex = 0;
            label18.Text = "Experiance:";
            // 
            // label7
            // 
            label7.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("Segoe UI", 12F);
            label7.Location = new System.Drawing.Point(595, 160);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(56, 21);
            label7.TabIndex = 0;
            label7.Text = "Salary:";
            // 
            // label11
            // 
            label11.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("Segoe UI", 12F);
            label11.Location = new System.Drawing.Point(595, 14);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(100, 21);
            label11.TabIndex = 0;
            label11.Text = "Date of Birth:";
            // 
            // label6
            // 
            label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Segoe UI", 12F);
            label6.Location = new System.Drawing.Point(398, 14);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(82, 21);
            label6.TabIndex = 0;
            label6.Text = "Phone No.";
            // 
            // label5
            // 
            label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Segoe UI", 12F);
            label5.Location = new System.Drawing.Point(200, 14);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(49, 21);
            label5.TabIndex = 0;
            label5.Text = "CNIC:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            label2.Location = new System.Drawing.Point(6, 14);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(55, 21);
            label2.TabIndex = 0;
            label2.Text = "Name:";
            // 
            // txtCnic
            // 
            txtCnic.Anchor = System.Windows.Forms.AnchorStyles.Top;
            txtCnic.Font = new System.Drawing.Font("Segoe UI", 9F);
            txtCnic.Location = new System.Drawing.Point(204, 38);
            txtCnic.Mask = "00000-0000000-0";
            txtCnic.Name = "txtCnic";
            txtCnic.Size = new System.Drawing.Size(159, 23);
            txtCnic.TabIndex = 1;
            // 
            // label1
            // 
            label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 15.75F);
            label1.Location = new System.Drawing.Point(273, 10);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(249, 30);
            label1.TabIndex = 7;
            label1.Text = "Add Surgeon Information";
            // 
            // ucAddSurgeon
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "ucAddSurgeon";
            Size = new System.Drawing.Size(824, 561);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudEcperiance).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudSalary).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnAddSurgeonInput;
        private System.Windows.Forms.DateTimePicker dtpEndTime;
        private System.Windows.Forms.DateTimePicker dtpDateOfBirth;
        private System.Windows.Forms.DateTimePicker dtpWHstart;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.NumericUpDown nudSalary;
        private System.Windows.Forms.Button btnClearInput;
        private System.Windows.Forms.RichTextBox txtAddress;
        private System.Windows.Forms.ComboBox cbDepartment;
        private System.Windows.Forms.MaskedTextBox txtPhoneNo;
        private System.Windows.Forms.MaskedTextBox txtCnic;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpWHend;
        private System.Windows.Forms.Button btnAddInput;
        private System.Windows.Forms.ComboBox cbQualification;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cbSpecialization;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown nudEcperiance;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbInvalidInput;
    }
}
