﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalManagementSystem
{
    class csMedicine
    {
        public String Name { get; set; }
        public String Id { get; set; }
        public String Description { get; set; }
        public DateTime Expiry_Date { get; set; }

        public double Price { get; set; }
    }
}
