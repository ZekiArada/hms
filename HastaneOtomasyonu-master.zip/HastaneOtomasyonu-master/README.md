# Hastane Otomasyon Sistemi

### Proje Raporu

![Proje Raporunu görmek için tıklayın.](https://github.com/busraozdemir0/HastaneOtomasyonu/blob/master/VTYS_Rapor.pdf)
