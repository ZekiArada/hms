﻿
namespace HastaneOtomasyonu
{
    partial class frmGirisPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGirisPaneli));
            this.pcrbxAdmin = new System.Windows.Forms.PictureBox();
            this.pcrbxSekreter = new System.Windows.Forms.PictureBox();
            this.pcrbxDoktor = new System.Windows.Forms.PictureBox();
            this.lblSekreter = new System.Windows.Forms.Label();
            this.lblAdmin = new System.Windows.Forms.Label();
            this.lblDoktor = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pctrbxCikis = new System.Windows.Forms.PictureBox();
            this.lblYedekle = new System.Windows.Forms.Label();
            this.lblYedektenDon = new System.Windows.Forms.Label();
            this.lblimportExport = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pcrbxAdmin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrbxSekreter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrbxDoktor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctrbxCikis)).BeginInit();
            this.SuspendLayout();
            // 
            // pcrbxAdmin
            // 
            this.pcrbxAdmin.Image = ((System.Drawing.Image)(resources.GetObject("pcrbxAdmin.Image")));
            this.pcrbxAdmin.Location = new System.Drawing.Point(47, 134);
            this.pcrbxAdmin.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.pcrbxAdmin.Name = "pcrbxAdmin";
            this.pcrbxAdmin.Size = new System.Drawing.Size(183, 173);
            this.pcrbxAdmin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrbxAdmin.TabIndex = 3;
            this.pcrbxAdmin.TabStop = false;
            this.pcrbxAdmin.Click += new System.EventHandler(this.pcrbxAdmin_Click);
            // 
            // pcrbxSekreter
            // 
            this.pcrbxSekreter.Image = ((System.Drawing.Image)(resources.GetObject("pcrbxSekreter.Image")));
            this.pcrbxSekreter.Location = new System.Drawing.Point(286, 134);
            this.pcrbxSekreter.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.pcrbxSekreter.Name = "pcrbxSekreter";
            this.pcrbxSekreter.Size = new System.Drawing.Size(183, 173);
            this.pcrbxSekreter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrbxSekreter.TabIndex = 4;
            this.pcrbxSekreter.TabStop = false;
            this.pcrbxSekreter.Click += new System.EventHandler(this.pcrbxSekreter_Click);
            // 
            // pcrbxDoktor
            // 
            this.pcrbxDoktor.Image = ((System.Drawing.Image)(resources.GetObject("pcrbxDoktor.Image")));
            this.pcrbxDoktor.Location = new System.Drawing.Point(538, 134);
            this.pcrbxDoktor.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.pcrbxDoktor.Name = "pcrbxDoktor";
            this.pcrbxDoktor.Size = new System.Drawing.Size(183, 173);
            this.pcrbxDoktor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcrbxDoktor.TabIndex = 5;
            this.pcrbxDoktor.TabStop = false;
            this.pcrbxDoktor.Click += new System.EventHandler(this.pcrbxDoktor_Click);
            // 
            // lblSekreter
            // 
            this.lblSekreter.AutoSize = true;
            this.lblSekreter.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold);
            this.lblSekreter.ForeColor = System.Drawing.Color.Black;
            this.lblSekreter.Location = new System.Drawing.Point(316, 314);
            this.lblSekreter.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblSekreter.Name = "lblSekreter";
            this.lblSekreter.Size = new System.Drawing.Size(119, 43);
            this.lblSekreter.TabIndex = 6;
            this.lblSekreter.Text = "Sekreter";
            // 
            // lblAdmin
            // 
            this.lblAdmin.AutoSize = true;
            this.lblAdmin.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAdmin.ForeColor = System.Drawing.Color.Black;
            this.lblAdmin.Location = new System.Drawing.Point(89, 314);
            this.lblAdmin.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblAdmin.Name = "lblAdmin";
            this.lblAdmin.Size = new System.Drawing.Size(101, 43);
            this.lblAdmin.TabIndex = 7;
            this.lblAdmin.Text = "Admin";
            // 
            // lblDoktor
            // 
            this.lblDoktor.AutoSize = true;
            this.lblDoktor.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold);
            this.lblDoktor.ForeColor = System.Drawing.Color.Black;
            this.lblDoktor.Location = new System.Drawing.Point(575, 314);
            this.lblDoktor.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblDoktor.Name = "lblDoktor";
            this.lblDoktor.Size = new System.Drawing.Size(103, 43);
            this.lblDoktor.TabIndex = 8;
            this.lblDoktor.Text = "Doktor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 34.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(251, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(316, 81);
            this.label1.TabIndex = 9;
            this.label1.Text = "Giriş Sayfası";
            // 
            // pctrbxCikis
            // 
            this.pctrbxCikis.Image = ((System.Drawing.Image)(resources.GetObject("pctrbxCikis.Image")));
            this.pctrbxCikis.Location = new System.Drawing.Point(712, 11);
            this.pctrbxCikis.Name = "pctrbxCikis";
            this.pctrbxCikis.Size = new System.Drawing.Size(34, 33);
            this.pctrbxCikis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctrbxCikis.TabIndex = 10;
            this.pctrbxCikis.TabStop = false;
            this.pctrbxCikis.Click += new System.EventHandler(this.pctrbxCikis_Click);
            // 
            // lblYedekle
            // 
            this.lblYedekle.AutoSize = true;
            this.lblYedekle.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYedekle.ForeColor = System.Drawing.Color.Black;
            this.lblYedekle.Location = new System.Drawing.Point(606, 12);
            this.lblYedekle.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblYedekle.Name = "lblYedekle";
            this.lblYedekle.Size = new System.Drawing.Size(87, 33);
            this.lblYedekle.TabIndex = 11;
            this.lblYedekle.Text = "Yedekle";
            this.lblYedekle.Click += new System.EventHandler(this.lblYedekle_Click);
            // 
            // lblYedektenDon
            // 
            this.lblYedektenDon.AutoSize = true;
            this.lblYedektenDon.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYedektenDon.ForeColor = System.Drawing.Color.Black;
            this.lblYedektenDon.Location = new System.Drawing.Point(606, 47);
            this.lblYedektenDon.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblYedektenDon.Name = "lblYedektenDon";
            this.lblYedektenDon.Size = new System.Drawing.Size(151, 33);
            this.lblYedektenDon.TabIndex = 12;
            this.lblYedektenDon.Text = "Yedekten Dön";
            this.lblYedektenDon.Click += new System.EventHandler(this.lblYedektenDon_Click);
            // 
            // lblimportExport
            // 
            this.lblimportExport.AutoSize = true;
            this.lblimportExport.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblimportExport.ForeColor = System.Drawing.Color.Black;
            this.lblimportExport.Location = new System.Drawing.Point(606, 82);
            this.lblimportExport.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblimportExport.Name = "lblimportExport";
            this.lblimportExport.Size = new System.Drawing.Size(159, 33);
            this.lblimportExport.TabIndex = 13;
            this.lblimportExport.Text = "Import/Export";
            this.lblimportExport.Click += new System.EventHandler(this.lblimportExport_Click);
            // 
            // frmGirisPaneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(204)))), ((int)(((byte)(231)))));
            this.ClientSize = new System.Drawing.Size(776, 369);
            this.Controls.Add(this.lblimportExport);
            this.Controls.Add(this.lblYedektenDon);
            this.Controls.Add(this.lblYedekle);
            this.Controls.Add(this.pctrbxCikis);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblDoktor);
            this.Controls.Add(this.lblAdmin);
            this.Controls.Add(this.lblSekreter);
            this.Controls.Add(this.pcrbxDoktor);
            this.Controls.Add(this.pcrbxSekreter);
            this.Controls.Add(this.pcrbxAdmin);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "frmGirisPaneli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GİRİŞ";
            ((System.ComponentModel.ISupportInitialize)(this.pcrbxAdmin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrbxSekreter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcrbxDoktor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctrbxCikis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pcrbxAdmin;
        private System.Windows.Forms.PictureBox pcrbxSekreter;
        private System.Windows.Forms.PictureBox pcrbxDoktor;
        private System.Windows.Forms.Label lblSekreter;
        private System.Windows.Forms.Label lblAdmin;
        private System.Windows.Forms.Label lblDoktor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pctrbxCikis;
        private System.Windows.Forms.Label lblYedekle;
        private System.Windows.Forms.Label lblYedektenDon;
        private System.Windows.Forms.Label lblimportExport;
    }
}

