﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyonu
{
    public class Hasta
    {
        public string HastaID { get; set; }
        public string HastaTc { get; set; }
        public string HastaAd { get; set; }
        public string HastaSoyad { get; set; }
        public string HastaTelefon { get; set; }
        public string HastaCinsiyet { get; set; }
        public string HastaDogumTarih { get; set; }
        public string SekreterID { get; set; }
    }
}
