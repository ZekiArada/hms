﻿
namespace HastaneOtomasyonu
{
    partial class frmSekreterEkran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSekreterEkran));
            this.label3 = new System.Windows.Forms.Label();
            this.pcbxRandevu = new System.Windows.Forms.PictureBox();
            this.pcbxBrans = new System.Windows.Forms.PictureBox();
            this.pcbxDoktor = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pcbxHasta = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pcbxAmeliyatRapor = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxRandevu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxBrans)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxDoktor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxHasta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxAmeliyatRapor)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Print", 34.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(243, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(399, 81);
            this.label3.TabIndex = 11;
            this.label3.Text = "Sekreter Ekranı";
            // 
            // pcbxRandevu
            // 
            this.pcbxRandevu.Image = ((System.Drawing.Image)(resources.GetObject("pcbxRandevu.Image")));
            this.pcbxRandevu.Location = new System.Drawing.Point(210, 115);
            this.pcbxRandevu.Name = "pcbxRandevu";
            this.pcbxRandevu.Size = new System.Drawing.Size(143, 131);
            this.pcbxRandevu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxRandevu.TabIndex = 12;
            this.pcbxRandevu.TabStop = false;
            this.pcbxRandevu.Click += new System.EventHandler(this.pcbxRandevu_Click);
            // 
            // pcbxBrans
            // 
            this.pcbxBrans.Image = ((System.Drawing.Image)(resources.GetObject("pcbxBrans.Image")));
            this.pcbxBrans.Location = new System.Drawing.Point(375, 115);
            this.pcbxBrans.Name = "pcbxBrans";
            this.pcbxBrans.Size = new System.Drawing.Size(143, 131);
            this.pcbxBrans.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxBrans.TabIndex = 13;
            this.pcbxBrans.TabStop = false;
            this.pcbxBrans.Click += new System.EventHandler(this.pcbxBrans_Click);
            // 
            // pcbxDoktor
            // 
            this.pcbxDoktor.Image = ((System.Drawing.Image)(resources.GetObject("pcbxDoktor.Image")));
            this.pcbxDoktor.Location = new System.Drawing.Point(44, 115);
            this.pcbxDoktor.Name = "pcbxDoktor";
            this.pcbxDoktor.Size = new System.Drawing.Size(143, 131);
            this.pcbxDoktor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxDoktor.TabIndex = 14;
            this.pcbxDoktor.TabStop = false;
            this.pcbxDoktor.Click += new System.EventHandler(this.pcbxDoktor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(62, 249);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 86);
            this.label1.TabIndex = 15;
            this.label1.Text = "Doktor\r\n Detay";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(221, 249);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 86);
            this.label2.TabIndex = 16;
            this.label2.Text = "Randevu \r\n Oluştur";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(397, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 86);
            this.label4.TabIndex = 17;
            this.label4.Text = "Branş \r\n Ekle";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(562, 249);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 86);
            this.label5.TabIndex = 19;
            this.label5.Text = "Hasta\r\n Ekle";
            // 
            // pcbxHasta
            // 
            this.pcbxHasta.Image = ((System.Drawing.Image)(resources.GetObject("pcbxHasta.Image")));
            this.pcbxHasta.Location = new System.Drawing.Point(535, 115);
            this.pcbxHasta.Name = "pcbxHasta";
            this.pcbxHasta.Size = new System.Drawing.Size(143, 131);
            this.pcbxHasta.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxHasta.TabIndex = 18;
            this.pcbxHasta.TabStop = false;
            this.pcbxHasta.Click += new System.EventHandler(this.pcbxHasta_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(697, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(150, 43);
            this.label7.TabIndex = 23;
            this.label7.Text = "Raporlama";
            // 
            // pcbxAmeliyatRapor
            // 
            this.pcbxAmeliyatRapor.Image = ((System.Drawing.Image)(resources.GetObject("pcbxAmeliyatRapor.Image")));
            this.pcbxAmeliyatRapor.Location = new System.Drawing.Point(705, 115);
            this.pcbxAmeliyatRapor.Name = "pcbxAmeliyatRapor";
            this.pcbxAmeliyatRapor.Size = new System.Drawing.Size(119, 131);
            this.pcbxAmeliyatRapor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxAmeliyatRapor.TabIndex = 22;
            this.pcbxAmeliyatRapor.TabStop = false;
            this.pcbxAmeliyatRapor.Click += new System.EventHandler(this.pcbxAmeliyatRapor_Click);
            // 
            // frmSekreterEkran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(204)))), ((int)(((byte)(231)))));
            this.ClientSize = new System.Drawing.Size(849, 354);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pcbxAmeliyatRapor);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pcbxHasta);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pcbxDoktor);
            this.Controls.Add(this.pcbxBrans);
            this.Controls.Add(this.pcbxRandevu);
            this.Controls.Add(this.label3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.Name = "frmSekreterEkran";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SEKRETER EKRANI";
            this.Load += new System.EventHandler(this.frmSekreterEkran_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pcbxRandevu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxBrans)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxDoktor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxHasta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxAmeliyatRapor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pcbxRandevu;
        private System.Windows.Forms.PictureBox pcbxBrans;
        private System.Windows.Forms.PictureBox pcbxDoktor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pcbxHasta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pcbxAmeliyatRapor;
    }
}