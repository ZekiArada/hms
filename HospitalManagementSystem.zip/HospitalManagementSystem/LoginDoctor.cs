using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HospitalManagementSystem.Data;
using Microsoft.EntityFrameworkCore;

namespace HospitalManagementSystem
{
    public partial class LoginDoctor : Form
    {
        public LoginDoctor()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string registrationNumber = txtRegistrationNumber.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(registrationNumber) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both Registration Number and Password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (registrationNumber.Length != 11 || password.Length != 11)
            {
                MessageBox.Show("Registration Number and Password must be 11 digits.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var context = new HospitalDbContext())
            {
                var doctor = context.Doctors.FirstOrDefault(d => d.RegistrationNumber == registrationNumber && d.PasswordD == password);

                if (doctor != null)
                {
                    // Login successful, navigate to HomeDoctor form (to be implemented)
                    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // HomeDoctor homeDoctor = new HomeDoctor(doctor);
                    // homeDoctor.Show();
                    // this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid Registration Number or Password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Hello hello = new Hello();
            hello.Show();
            this.Hide();
        }

        private void LoginDoctor_Load(object sender, EventArgs e)
        {

        }
    }
} 