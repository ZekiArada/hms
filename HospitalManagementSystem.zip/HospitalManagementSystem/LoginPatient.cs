using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HospitalManagementSystem.Data;
using Microsoft.EntityFrameworkCore;

namespace HospitalManagementSystem
{
    public partial class LoginPatient : Form
    {
        public LoginPatient()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string tcNo = txtTcNo.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(tcNo) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both T.C. No and Password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (tcNo.Length != 11 || password.Length != 11)
            {
                MessageBox.Show("T.C. No and Password must be 11 digits.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (var context = new HospitalDbContext())
            {
                var patient = context.Patients.FirstOrDefault(p => p.TcNo == tcNo && p.PasswordP == password);

                if (patient != null)
                {
                    // Login successful, navigate to HomePatient form (to be implemented)
                    MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    // HomePatient homePatient = new HomePatient(patient);
                    // homePatient.Show();
                    // this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid T.C. No or Password.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Hello hello = new Hello();
            hello.Show();
            this.Hide();
        }
    }
} 