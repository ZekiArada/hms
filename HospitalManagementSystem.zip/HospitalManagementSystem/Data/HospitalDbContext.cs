using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Data
{
    public class HospitalDbContext : DbContext
    {
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<MedicalRecord> MedicalRecords { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=hospital.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure Doctor
            modelBuilder.Entity<Doctor>()
                .HasKey(d => d.Id);
            
            modelBuilder.Entity<Doctor>()
                .Property(d => d.RegistrationNumber)
                .IsRequired()
                .HasMaxLength(11);
            
            modelBuilder.Entity<Doctor>()
                .Property(d => d.PasswordD)
                .IsRequired()
                .HasMaxLength(11);

            // Configure Patient
            modelBuilder.Entity<Patient>()
                .HasKey(p => p.Id);
            
            modelBuilder.Entity<Patient>()
                .Property(p => p.TcNo)
                .IsRequired()
                .HasMaxLength(11);
            
            modelBuilder.Entity<Patient>()
                .Property(p => p.PasswordP)
                .IsRequired()
                .HasMaxLength(11);

            // Configure Appointment
            modelBuilder.Entity<Appointment>()
                .HasKey(a => a.Id);
            
            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Doctor)
                .WithMany()
                .HasForeignKey(a => a.DoctorId)
                .OnDelete(DeleteBehavior.Restrict);
            
            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Patient)
                .WithMany()
                .HasForeignKey(a => a.PatientId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure MedicalRecord
            modelBuilder.Entity<MedicalRecord>()
                .HasKey(m => m.Id);
            
            modelBuilder.Entity<MedicalRecord>()
                .HasOne(m => m.Doctor)
                .WithMany()
                .HasForeignKey(m => m.DoctorId)
                .OnDelete(DeleteBehavior.Restrict);
            
            modelBuilder.Entity<MedicalRecord>()
                .HasOne(m => m.Patient)
                .WithMany()
                .HasForeignKey(m => m.PatientId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
} 