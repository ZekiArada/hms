using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace HospitalManagementSystem.Data
{
    public static class DbInitializer
    {
        public static void Initialize(HospitalDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Doctors.Any() || context.Patients.Any())
            {
                return;
            }

            // Add sample doctors (CONSTRUCTOR İLE OLUŞTURULDU)
            var doctors = new Doctor[]
            {
            new Doctor(
                fullName: "Dr. Ahmet Yılmaz",
                registrationNumber: "12345678901",
                passwordD: "12345678901",
                specialization: "Cardiology",
                contactNumber: "5551112233",
                email: "ahmet.yilmaz@hospital.com",
                //dateOfBirth: new DateTime(1975, 5, 15),
                //BU OTOMATİK Mİ VERİLCEK OBJE YARATILINCA. VERİLMEZSEDE MÜHİM DEĞİL 
                gender: "Male",
                address: "Istanbul, Turkey"
            ),
            new Doctor(
                fullName: "Dr. Ayşe Kaya",
                registrationNumber: "23456789012",
                passwordD: "23456789012",
                specialization: "Neurology",
                contactNumber: "5552223344",
                email: "ayse.kaya@hospital.com",
                //dateOfBirth: new DateTime(1980, 8, 20),
                //BU OTOMATİK Mİ VERİLCEK OBJE YARATILINCA. VERİLMEZSEDE MÜHİM DEĞİL 
                gender: "Female",
                address: "Ankara, Turkey"
            )
            };

            context.Doctors.AddRange(doctors);
            context.SaveChanges();

            // Add sample patients (CONSTRUCTOR İLE OLUŞTURULDU)
            var patients = new Patient[]
            {
            new Patient(
                fullName: "Mehmet Demir",
                tcNo: "98765432109",
                passwordP: "98765432109",
                dateOfBirth: new DateTime(1990, 3, 10),
                gender: "Male",
                bloodGroup: "A+",
                contactNumber: "5553334455"
            )
            {
                // Optional properties (constructor dışındakiler)
                Email = "mehmet.demir@example.com",
                Address = "Istanbul, Turkey",
                MedicalHistory = "No chronic diseases"
            },
            new Patient(
                fullName: "Zeynep Çelik",
                tcNo: "87654321098",
                passwordP: "87654321098",
                dateOfBirth: new DateTime(1985, 7, 25),
                gender: "Female",
                bloodGroup: "O+",
                contactNumber: "5554445566"
            )
            {
                Email = "zeynep.celik@example.com",
                Address = "Izmir, Turkey",
                MedicalHistory = "Allergic to penicillin"
            }
            };

            context.Patients.AddRange(patients);
            context.SaveChanges();
        }
    }
} 