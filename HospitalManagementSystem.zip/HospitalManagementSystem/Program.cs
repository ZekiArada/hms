using HospitalManagementSystem.Data;

namespace HospitalManagementSystem
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            
            // Initialize database with sample data
            using (var context = new HospitalDbContext())
            {
                DbInitializer.Initialize(context);
            }
            
            Application.Run(new Hello());
        }
    }
}