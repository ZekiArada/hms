using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementSystem.Models
{
    public class Doctor
    {
        public Doctor(
            string fullName,
            string registrationNumber,
            string passwordD,
            string specialization,
            string contactNumber,
            string email,
            string gender,
            string address)
        {
            FullName = fullName;
            RegistrationNumber = registrationNumber;
            PasswordD = passwordD;
            Specialization = specialization;
            ContactNumber = contactNumber;
            Email = email;
            Gender = gender;
            Address = address;
        }

        public int Id { get; set; }
        public string FullName { get; set; }
        public string RegistrationNumber { get; set; }
        public string PasswordD { get; set; }
        public string Specialization { get; set; }
        public string ContactNumber { get; set; }
        public string Email { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
    }
} 