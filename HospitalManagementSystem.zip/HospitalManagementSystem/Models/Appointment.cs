﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementSystem.Models
{
    public class Appointment
    {
        // Constructor: DoctorId, PatientId ve ilişkili nesneler zorunlu
        public Appointment(
            int doctorId,
            int patientId,
            DateTime appointmentDate,
            TimeSpan appointmentTime,
            Doctor doctor,
            Patient patient)
        {
            DoctorId = doctorId;
            PatientId = patientId;
            AppointmentDate = appointmentDate;
            AppointmentTime = appointmentTime;
            Doctor = doctor;
            Patient = patient;
        }

        public int Id { get; set; }
        public int DoctorId { get; set; }
        public int PatientId { get; set; }
        public DateTime AppointmentDate { get; set; }
        public TimeSpan AppointmentTime { get; set; }
        public string? Status { get; set; } // Scheduled, Completed, Cancelled
        public string? Description { get; set; }

        // Navigation properties (non-nullable)
        // YA BURDAKİ DOCTOR VE PATİENT NE ANLAMADIM Kİ TABLONUN ADLARI BUNLAR BURDA BİR HATA VAR FORGEİN KEY MANTIKLI DURUYOR

        /*
         public class Appointment
{
    public Appointment(
        int doctorId,
        int patientId,
        DateTime appointmentDate,
        TimeSpan appointmentTime)
    {
        DoctorId = doctorId;
        PatientId = patientId;
        AppointmentDate = appointmentDate;
        AppointmentTime = appointmentTime;
    }

    public int Id { get; set; }
    public int DoctorId { get; set; }
    public int PatientId { get; set; }
    public DateTime AppointmentDate { get; set; }
    public TimeSpan AppointmentTime { get; set; }
    public string? Status { get; set; }
    public string? Description { get; set; }
    
    // Navigation properties kaldırıldı (opsiyonel)
}
         */

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
    }
}