using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementSystem.Models
{
    public class MedicalRecord
    {
        // Constructor for required fields
        public MedicalRecord(
            int patientId,
            int doctorId,
            DateTime recordDate,
            string diagnosis,
            string treatment,
            string prescription)
        {
            PatientId = patientId;
            DoctorId = doctorId;
            RecordDate = recordDate;
            Diagnosis = diagnosis;
            Treatment = treatment;
            Prescription = prescription;
        }

        public int Id { get; set; }
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public DateTime RecordDate { get; set; }
        public string Diagnosis { get; set; } // Art?k null olamaz
        public string Treatment { get; set; } // Art?k null olamaz
        public string Prescription { get; set; } // Art?k null olamaz
        /*public string Notes { get; set; } = string.Empty; // ?ste?e ba?l? (varsay?lan de?er atand?)*/

        // Navigation properties (null olabilir, ��nk� EF Core ili?kiyi sonradan doldurabilir)
        // BU KISMI B?R DAHA G�ZDEN GE�?RMEN LAZIM !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        public Patient? Patient { get; set; }
        public Doctor? Doctor { get; set; }
        public string? Notes { get; set; } // Nullable
    }
}