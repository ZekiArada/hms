using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementSystem.Models
{
    public class Patient
    {
        // Constructor for non-nullable properties
        public Patient(
            string fullName,
            string tcNo,
            string passwordP,
            DateTime dateOfBirth,
            string gender,
            string bloodGroup,
            string contactNumber)
        {
            FullName = fullName;
            TcNo = tcNo;
            PasswordP = passwordP;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            BloodGroup = bloodGroup;
            ContactNumber = contactNumber;
        }

        public int Id { get; set; }
        public string FullName { get; set; }
        public string TcNo { get; set; } // 11 digits (non-nullable)
        public string PasswordP { get; set; } // 11 digits (non-nullable)
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string BloodGroup { get; set; }
        public string ContactNumber { get; set; }

        // Nullable properties (optional)
        public string? Email { get; set; }
        public string? Address { get; set; }
        public string? MedicalHistory { get; set; }
    }
} 