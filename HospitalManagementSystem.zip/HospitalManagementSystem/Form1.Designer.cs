﻿namespace HospitalManagementSystem
{
    partial class Hello
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblWelcome = new Label();
            btnDoctor = new Button();
            btnPatient = new Button();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            lblWelcome.Location = new Point(152, 60);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(496, 37);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Welcome to Hospital Management System";
            lblWelcome.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnDoctor
            // 
            btnDoctor.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            btnDoctor.Location = new Point(200, 200);
            btnDoctor.Name = "btnDoctor";
            btnDoctor.Size = new Size(200, 60);
            btnDoctor.TabIndex = 1;
            btnDoctor.Text = "Doctor";
            btnDoctor.UseVisualStyleBackColor = true;
            btnDoctor.Click += btnDoctor_Click;
            // 
            // btnPatient
            // 
            btnPatient.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            btnPatient.Location = new Point(400, 200);
            btnPatient.Name = "btnPatient";
            btnPatient.Size = new Size(200, 60);
            btnPatient.TabIndex = 2;
            btnPatient.Text = "Patient";
            btnPatient.UseVisualStyleBackColor = true;
            btnPatient.Click += btnPatient_Click;
            // 
            // Hello
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnPatient);
            Controls.Add(btnDoctor);
            Controls.Add(lblWelcome);
            Name = "Hello";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hospital Management System";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWelcome;
        private Button btnDoctor;
        private Button btnPatient;
    }
}
