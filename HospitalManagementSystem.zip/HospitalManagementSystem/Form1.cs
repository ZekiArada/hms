using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HospitalManagementSystem
{
    public partial class Hello : Form
    {
        public Hello()
        {
            InitializeComponent();
        }

        private void btnDoctor_Click(object sender, EventArgs e)
        {
            LoginDoctor loginDoctor = new LoginDoctor();
            loginDoctor.Show();
            this.Hide();
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            LoginPatient loginPatient = new LoginPatient();
            loginPatient.Show();
            this.Hide();
        }
    }
}
